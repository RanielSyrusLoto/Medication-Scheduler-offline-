import React, { useState, useEffect, useRef } from 'react';
import { Plus, Trash2, AlertCircle, AlertTriangle, Check, Search, X, Pill, PackagePlus, Sparkles, Filter, Calendar, Camera, Upload, Image as ImageIcon } from 'lucide-react';
import { callApi } from '../utils/pywebview';
import { User, Medication } from '../types';

interface MedicationsViewProps {
  user: User | null;
  onDataChange?: () => void;
}

interface StatusMsg {
  text: string;
  isError: boolean;
}

type StockFilterType = 'ALL' | 'LOW_STOCK' | 'IN_STOCK';

export default function MedicationsView({ user, onDataChange }: MedicationsViewProps): React.JSX.Element {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [stockFilter, setStockFilter] = useState<StockFilterType>('ALL');

  // Modal State for Register New Drug (matching user screenshot)
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [strengthVal, setStrengthVal] = useState<string>('500');
  const [strengthUnit, setStrengthUnit] = useState<string>('mg');
  const [dosageForm, setDosageForm] = useState<string>('Capsule');
  const [stock, setStock] = useState<string>('30');
  const [stockUnit, setStockUnit] = useState<string>('capsules');
  const [threshold, setThreshold] = useState<string>('10');
  const [expirationDate, setExpirationDate] = useState<string>('');
  const [imageData, setImageData] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [formMsg, setFormMsg] = useState<StatusMsg>({ text: '', isError: false });
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Modal State for Restock
  const [showRestockModal, setShowRestockModal] = useState<boolean>(false);
  const [restockMedObj, setRestockMedObj] = useState<Medication | null>(null);
  const [addStockAmount, setAddStockAmount] = useState<string>('30');
  const [restockMsg, setRestockMsg] = useState<StatusMsg>({ text: '', isError: false });
  const [restocking, setRestocking] = useState<boolean>(false);

  // Modal State for Delete Confirmation
  const [pendingDeleteMed, setPendingDeleteMed] = useState<Medication | null>(null);

  const fetchMeds = async () => {
    if (!user?.user_id) return;
    setLoading(true);
    const res = await callApi('get_medications', user.user_id);
    if (res.success) {
      setMedications(res.medications || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMeds();
  }, [user]);

  const handleOpenRestock = (med: Medication) => {
    setRestockMedObj(med);
    setAddStockAmount('30');
    setRestockMsg({ text: '', isError: false });
    setShowRestockModal(true);
  };

  const handleConfirmRestock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!restockMedObj) return;

    const amt = parseInt(addStockAmount, 10);
    if (isNaN(amt) || amt <= 0) {
      setRestockMsg({ text: 'Please enter a valid amount greater than 0.', isError: true });
      return;
    }

    setRestocking(true);
    try {
      const res = await callApi('restock_medication', restockMedObj.med_id, amt);
      if (res.success) {
        setRestockMsg({ text: `Added ${amt} ${restockMedObj.stock_unit || 'tablets'} to stock!`, isError: false });
        fetchMeds();
        if (onDataChange) onDataChange();
        setTimeout(() => {
          setShowRestockModal(false);
          setRestockMedObj(null);
          setRestockMsg({ text: '', isError: false });
        }, 800);
      } else {
        setRestockMsg({ text: res.message || 'Failed to add stock.', isError: true });
      }
    } catch (err) {
      setRestockMsg({ text: 'Error adding stock.', isError: true });
    } finally {
      setRestocking(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormMsg({ text: 'Please select a valid image file (PNG/JPG/WEBP).', isError: true });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 400;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setImageData(dataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleAddMedication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.user_id) return;
    setFormMsg({ text: '', isError: false });

    if (!name.trim()) {
      setFormMsg({ text: 'Please enter Medicine Name.', isError: true });
      return;
    }

    setSubmitting(true);
    try {
      const cleanStrengthVal = strengthVal.trim() || '500';
      const cleanStrengthUnit = strengthUnit.trim() || 'mg';
      const computedStrength = `${cleanStrengthVal} ${cleanStrengthUnit}`;
      const computedDosage = computedStrength;
      const computedForm = dosageForm || 'Capsule';
      const computedUnit = stockUnit || 'capsules';
      const computedStock = parseInt(stock, 10) || 30;
      const computedThreshold = parseInt(threshold, 10) || 10;
      const cleanExpiration = expirationDate.trim() || null;

      const res = await callApi(
        'add_medication',
        user.user_id,
        name.trim(),
        computedDosage,
        computedStock,
        computedThreshold,
        imageData || null, // Saves user photo or null (keeps default image)
        computedStrength,
        computedForm,
        computedUnit,
        null,
        null,
        cleanExpiration
      );

      if (res && res.success) {
        setFormMsg({ text: 'Medicine registered to inventory successfully!', isError: false });
        fetchMeds();
        if (onDataChange) onDataChange();
        setTimeout(() => {
          setShowAddModal(false);
          setName('');
          setStrengthVal('500');
          setStrengthUnit('mg');
          setDosageForm('Capsule');
          setStock('30');
          setStockUnit('capsules');
          setThreshold('10');
          setExpirationDate('');
          setImageData('');
          setFormMsg({ text: '', isError: false });
        }, 800);
      } else {
        setFormMsg({ text: res?.message || 'Failed to add medication.', isError: true });
      }
    } catch (err) {
      setFormMsg({ text: 'Error saving medication.', isError: true });
    } finally {
      setSubmitting(false);
    }
  };

  const confirmDeleteMed = async () => {
    if (!pendingDeleteMed) return;
    const target = pendingDeleteMed;
    setPendingDeleteMed(null);
    try {
      const res = await callApi('delete_medication', target.med_id);
      if (res.success) {
        fetchMeds();
        if (onDataChange) onDataChange();
      }
    } catch (err) {
      console.error('Delete error', err);
    }
  };

  // Filtered meds
  const filteredMeds = medications.filter((m) => {
    const matchesSearch =
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.dosage || '').toLowerCase().includes(searchTerm.toLowerCase());

    const isLow = m.is_low_stock || (m.stock <= (m.refill_threshold || 10));

    if (stockFilter === 'LOW_STOCK') return matchesSearch && isLow;
    if (stockFilter === 'IN_STOCK') return matchesSearch && !isLow && m.stock > 0;
    return matchesSearch;
  });

  const lowStockMeds = medications.filter(
    (m) => m.is_low_stock || m.stock <= (m.refill_threshold || 10)
  );

  const cardColors = [
    { circle: 'bg-teal-100 dark:bg-teal-500/20 text-[#2E7D7E] dark:text-[#2dd4bf]', bar: 'bg-[#2E7D7E] dark:bg-[#2dd4bf]' },
    { circle: 'bg-amber-100 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400', bar: 'bg-amber-500' },
    { circle: 'bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400', bar: 'bg-rose-500' },
    { circle: 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400', bar: 'bg-emerald-500' },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-7 flex flex-col h-full overflow-hidden transition-colors duration-200">
      {/* 1. STICKY TOP BAR: Search + Filter Chips + Add Medication (Fixed at Top) */}
      <div className="shrink-0 pb-4 mb-4 border-b border-[#E3E8EE] dark:border-[#1c3345] bg-[#F3F6F9] dark:bg-[#0c1722] z-10">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 flex-wrap">
          {/* Search Input Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8B9DA8]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search medication stock by name, strength, dosage..."
              className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-xl text-xs text-[#1E2837] dark:text-white placeholder-[#8B9DA8] focus:outline-none focus:border-[#2E7D7E] dark:focus:border-[#2dd4bf] shadow-xs transition-all"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B9DA8] hover:text-[#1E2837]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Pills & Add Medication Button */}
          <div className="flex items-center gap-3 self-end sm:self-auto">
            {/* Quick Filter Segment */}
            <div className="inline-flex p-1 bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-xl gap-1 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setStockFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  stockFilter === 'ALL'
                    ? 'bg-[#EBF5F5] dark:bg-[#183641] text-[#2E7D7E] dark:text-[#2dd4bf]'
                    : 'text-[#8B9DA8] hover:text-[#1E2837]'
                }`}
              >
                All ({medications.length})
              </button>
              <button
                type="button"
                onClick={() => setStockFilter('IN_STOCK')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  stockFilter === 'IN_STOCK'
                    ? 'bg-[#EBF5F5] dark:bg-[#183641] text-[#2E7D7E] dark:text-[#2dd4bf]'
                    : 'text-[#8B9DA8] hover:text-[#1E2837]'
                }`}
              >
                In Stock
              </button>
              <button
                type="button"
                onClick={() => setStockFilter('LOW_STOCK')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  stockFilter === 'LOW_STOCK'
                    ? 'bg-rose-50 dark:bg-rose-500/15 text-rose-600 dark:text-rose-400'
                    : 'text-[#8B9DA8] hover:text-[#1E2837]'
                }`}
              >
                Low Stock ({lowStockMeds.length})
              </button>
            </div>

            {/* Add Medication Button */}
            <button
              type="button"
              onClick={() => {
                setFormMsg({ text: '', isError: false });
                setShowAddModal(true);
              }}
              className="py-2.5 px-4 bg-[#2E7D7E] hover:bg-[#26696a] text-white font-semibold text-xs rounded-xl shadow-sm transition-all flex items-center gap-2 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Add Medication</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. SCROLLABLE CARDS AREA */}
      <div className="flex-1 min-h-0 overflow-y-auto pr-1.5 space-y-6">
        {/* Main Stock Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 2xl:grid-cols-3 gap-5">
          {filteredMeds.length === 0 ? (
            <div className="col-span-1 md:col-span-2 2xl:col-span-3 py-12 text-center text-[#8B9DA8] dark:text-[#859ba8] bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-2xl p-8">
              <Pill className="w-8 h-8 mx-auto text-[#2E7D7E]/50 mb-2" />
              <p className="text-xs font-semibold text-[#1E2837] dark:text-white">
                {searchTerm ? 'No matching medications found' : 'No medications registered yet'}
              </p>
              <p className="text-xs text-[#8B9DA8] mt-1">
                {searchTerm ? 'Try a different search term or clear the filter.' : 'Add your prescriptions to start tracking stock and schedules.'}
              </p>
            </div>
          ) : (
            filteredMeds.map((med, idx) => {
              const colors = cardColors[idx % cardColors.length];
              const maxExpected = Math.max(med.stock, 30);
              const percentage = Math.min(100, Math.round((med.stock / maxExpected) * 100));
              const isLow = med.is_low_stock || med.stock <= (med.refill_threshold || 10);

              return (
                <div
                  key={med.med_id}
                  className="bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between gap-4 group"
                >
                  {/* Top Header Row with Photo or Default Icon */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3.5 min-w-0">
                      {med.image_path ? (
                        <div className="w-11 h-11 min-w-[44px] min-h-[44px] max-w-[44px] max-h-[44px] aspect-square rounded-2xl overflow-hidden border border-[#E3E8EE] dark:border-[#1c3345] shrink-0 shadow-xs bg-[#F3F6F9] dark:bg-[#172838] flex items-center justify-center">
                          <img
                            src={med.image_path}
                            alt={med.name}
                            className="w-full h-full object-cover rounded-2xl"
                            style={{ width: '44px', height: '44px' }}
                          />
                        </div>
                      ) : (
                        <div className={`w-11 h-11 min-w-[44px] min-h-[44px] max-w-[44px] max-h-[44px] aspect-square rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${colors.circle}`}>
                          <Pill className="w-6 h-6 -rotate-45" />
                        </div>
                      )}

                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-sm font-bold text-[#1E2837] dark:text-white truncate">
                            {med.name}
                          </h3>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800/50">
                            {med.dosage_form || 'Tablet'}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-[#2E7D7E] dark:text-[#2dd4bf] mt-0.5">
                          {med.strength || med.dosage || 'Standard Strength'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenRestock(med)}
                        className="px-2.5 py-1 text-[11px] font-semibold bg-[#F3F6F9] dark:bg-[#172838] border border-[#E3E8EE] dark:border-[#1c3345] text-[#2E7D7E] dark:text-[#2dd4bf] hover:bg-[#EBF5F5] dark:hover:bg-[#183641] rounded-lg transition-colors flex items-center gap-1"
                      >
                        <PackagePlus className="w-3 h-3" />
                        <span>Restock</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPendingDeleteMed(med)}
                        className="p-1 text-[#8B9DA8] hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-colors"
                        title="Delete Medication"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Adjusted Specs Display Grid */}
                  <div className="grid grid-cols-2 gap-2 py-2 px-3 rounded-xl bg-[#F8FAFC] dark:bg-[#101b26] border border-[#E3E8EE]/60 dark:border-[#1c3345]/60 text-[11px]">
                    <div>
                      <span className="text-[#8B9DA8] dark:text-[#859ba8] block text-[10px] font-medium">Quantity in Stock</span>
                      <strong className="text-[#1E2837] dark:text-white font-semibold">
                        {med.stock} {med.stock_unit || 'tablets'}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[#8B9DA8] dark:text-[#859ba8] block text-[10px] font-medium">Low Stock Alert</span>
                      <strong className="text-[#1E2837] dark:text-white font-semibold">
                        ≤ {med.refill_threshold || 10} {med.stock_unit || 'tablets'}
                      </strong>
                    </div>
                    {med.expiration_date && (
                      <div className="col-span-2 pt-1 border-t border-[#E3E8EE]/40 dark:border-[#1c3345]/40 flex items-center gap-1 text-[10px] text-[#8B9DA8]">
                        <Calendar className="w-3 h-3 text-[#2E7D7E] dark:text-[#2dd4bf]" />
                        <span>Expires: <strong className="text-[#1E2837] dark:text-white">{med.expiration_date}</strong></span>
                      </div>
                    )}
                  </div>

                  {/* Progress Bar & Percentage */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-medium text-[#8B9DA8] dark:text-[#859ba8]">
                      <span>Stock Level</span>
                      <span>{percentage}%</span>
                    </div>
                    <div className="w-full bg-[#F3F6F9] dark:bg-[#172838] h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isLow ? 'bg-rose-500' : colors.bar
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Low Stock Section matching reference image */}
        {lowStockMeds.length > 0 && (
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
                Low Stock
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {lowStockMeds.map((med) => (
                <div
                  key={`low-${med.med_id}`}
                  className="bg-white dark:bg-[#13222f] border border-rose-200 dark:border-rose-900/50 rounded-2xl p-4 shadow-sm flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {med.image_path ? (
                      <div className="w-10 h-10 min-w-[40px] min-h-[40px] max-w-[40px] max-h-[40px] aspect-square rounded-xl overflow-hidden border border-rose-200 dark:border-rose-900/50 shrink-0 flex items-center justify-center">
                        <img src={med.image_path} alt={med.name} className="w-full h-full object-cover rounded-xl" style={{ width: '40px', height: '40px' }} />
                      </div>
                    ) : (
                      <div className="w-10 h-10 min-w-[40px] min-h-[40px] max-w-[40px] max-h-[40px] aspect-square rounded-xl bg-rose-50 dark:bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-[#1E2837] dark:text-white truncate">
                        {med.name} {med.strength || med.dosage}
                      </h4>
                      <p className="text-[11px] text-[#8B9DA8] dark:text-[#859ba8]">
                        {med.stock} {med.stock_unit || 'tablets'} remaining
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-50 text-rose-600 border border-rose-200 dark:bg-rose-500/15 dark:text-rose-400 dark:border-rose-500/20">
                      (25% or less)
                    </span>
                    <button
                      type="button"
                      onClick={() => handleOpenRestock(med)}
                      className="px-3 py-1 bg-[#2E7D7E] text-white text-[11px] font-semibold rounded-lg hover:bg-[#26696a] transition-all shadow-xs"
                    >
                      Restock
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* REGISTER NEW DRUG MODAL (matching reference image) */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-[560px] my-auto bg-white dark:bg-[#131d27] border border-[#E3E8EE] dark:border-[#223142] rounded-3xl p-6 sm:p-7 shadow-2xl animate-fadeIn space-y-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#E3E8EE] dark:border-[#1e2d3d]">
              <div className="flex items-center gap-3">
                {imageData ? (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="w-10 h-10 min-w-[40px] min-h-[40px] max-w-[40px] max-h-[40px] aspect-square rounded-2xl overflow-hidden border border-purple-500/40 shrink-0 flex items-center justify-center cursor-pointer relative group"
                    title="Change medicine photo"
                  >
                    <img src={imageData} alt="Medicine preview" className="w-full h-full object-cover rounded-2xl" style={{ width: '40px', height: '40px' }} />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded-2xl">
                      <Camera className="w-3.5 h-3.5 text-white" />
                    </div>
                  </div>
                ) : (
                  <div className="w-10 h-10 min-w-[40px] min-h-[40px] max-w-[40px] max-h-[40px] aspect-square rounded-2xl bg-purple-500/15 border border-purple-500/30 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
                    <Pill className="w-5 h-5 -rotate-45" />
                  </div>
                )}
                <div>
                  <h3 className="text-base font-bold text-[#1E2837] dark:text-white leading-tight">
                    Register New Drug
                  </h3>
                  <p className="text-xs text-[#8B9DA8] dark:text-[#859ba8] mt-0.5">
                    Add new medicine to stock inventory.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-[#8B9DA8] hover:text-[#1E2837] dark:hover:text-white hover:bg-[#F3F6F9] dark:hover:bg-[#1a2838] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formMsg.text && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  formMsg.isError
                    ? 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400 border border-rose-200 dark:border-rose-500/20'
                    : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20'
                }`}
              >
                {formMsg.isError ? <AlertCircle className="w-4 h-4 shrink-0" /> : <Check className="w-4 h-4 shrink-0" />}
                <span>{formMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleAddMedication} className="space-y-4">
              {/* Field 1: Medicine Name */}
              <div>
                <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                  Medicine Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Biogesic"
                  className="w-full px-4 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white placeholder-[#8B9DA8] focus:outline-none focus:border-purple-500 transition-all"
                />
              </div>

              {/* Row: Medicine Strength & Type of Medicine */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                    Medicine Strength
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      required
                      value={strengthVal}
                      onChange={(e) => setStrengthVal(e.target.value)}
                      placeholder="500"
                      className="flex-1 px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 transition-all"
                    />
                    <select
                      value={strengthUnit}
                      onChange={(e) => setStrengthUnit(e.target.value)}
                      className="w-24 px-3 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 cursor-pointer"
                    >
                      <option value="mg" className="dark:bg-[#131d27]">mg</option>
                      <option value="g" className="dark:bg-[#131d27]">g</option>
                      <option value="ml" className="dark:bg-[#131d27]">ml</option>
                      <option value="mcg" className="dark:bg-[#131d27]">mcg</option>
                      <option value="IU" className="dark:bg-[#131d27]">IU</option>
                      <option value="drop" className="dark:bg-[#131d27]">drop</option>
                      <option value="tablet" className="dark:bg-[#131d27]">tablet</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                    Type of Medicine
                  </label>
                  <select
                    value={dosageForm}
                    onChange={(e) => setDosageForm(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 cursor-pointer"
                  >
                    <option value="Capsule" className="dark:bg-[#131d27]">Capsule</option>
                    <option value="Tablet" className="dark:bg-[#131d27]">Tablet</option>
                    <option value="Syrup" className="dark:bg-[#131d27]">Syrup</option>
                    <option value="Injection" className="dark:bg-[#131d27]">Injection</option>
                    <option value="Drops" className="dark:bg-[#131d27]">Drops</option>
                    <option value="Ointment" className="dark:bg-[#131d27]">Ointment</option>
                    <option value="Inhaler" className="dark:bg-[#131d27]">Inhaler</option>
                    <option value="Patch" className="dark:bg-[#131d27]">Patch</option>
                    <option value="Suppository" className="dark:bg-[#131d27]">Suppository</option>
                  </select>
                </div>
              </div>

              {/* Row: How Many Do You Have? & Alert Me When Stock Reaches */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                    How Many Do You Have?
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="1"
                      required
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      placeholder="30"
                      className="flex-1 px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 transition-all"
                    />
                    <select
                      value={stockUnit}
                      onChange={(e) => setStockUnit(e.target.value)}
                      className="w-28 px-3 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 cursor-pointer"
                    >
                      <option value="capsules" className="dark:bg-[#131d27]">capsules</option>
                      <option value="tablets" className="dark:bg-[#131d27]">tablets</option>
                      <option value="pills" className="dark:bg-[#131d27]">pills</option>
                      <option value="bottles" className="dark:bg-[#131d27]">bottles</option>
                      <option value="vials" className="dark:bg-[#131d27]">vials</option>
                      <option value="packs" className="dark:bg-[#131d27]">packs</option>
                      <option value="pieces" className="dark:bg-[#131d27]">pieces</option>
                      <option value="ml" className="dark:bg-[#131d27]">ml</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                    Alert Me When Stock Reaches
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={threshold}
                    onChange={(e) => setThreshold(e.target.value)}
                    placeholder="10"
                    className="w-full px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 transition-all"
                  />
                </div>
              </div>

              {/* Expiration Date (Optional) */}
              <div>
                <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                  Expiration Date (Optional)
                </label>
                <input
                  type="date"
                  value={expirationDate}
                  onChange={(e) => setExpirationDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#182635] border border-[#E3E8EE] dark:border-[#26374a] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-purple-500 cursor-pointer"
                />
              </div>

              {/* Medicine Photo / Picture Upload (Optional) */}
              <div>
                <label className="block text-xs font-semibold text-[#1E2837] dark:text-white mb-1.5">
                  Medicine Photo (Optional)
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />

                {imageData ? (
                  <div className="flex items-center justify-between p-2.5 rounded-xl border border-purple-500/40 bg-purple-500/5">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 min-w-[44px] min-h-[44px] max-w-[44px] max-h-[44px] aspect-square rounded-2xl overflow-hidden border border-purple-500/30 shrink-0 flex items-center justify-center bg-[#F3F6F9] dark:bg-[#182635]">
                        <img src={imageData} alt="Medicine preview" className="w-full h-full object-cover rounded-2xl" style={{ width: '44px', height: '44px' }} />
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-[#1E2837] dark:text-white block">Custom Photo Attached</span>
                        <span className="text-[10px] text-[#8B9DA8]">Matches default icon size identically</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-2.5 py-1 text-[11px] font-semibold text-purple-600 dark:text-purple-400 hover:underline"
                      >
                        Change
                      </button>
                      <button
                        type="button"
                        onClick={() => setImageData('')}
                        className="p-1 text-[#8B9DA8] hover:text-rose-500 transition-colors"
                        title="Remove photo (use default icon)"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2.5 px-3.5 rounded-xl border border-dashed border-[#E3E8EE] dark:border-[#26374a] hover:border-purple-500 bg-[#F3F6F9]/40 dark:bg-[#182635]/30 hover:bg-purple-500/5 transition-all flex items-center justify-between text-xs text-[#8B9DA8] hover:text-[#1E2837] dark:hover:text-white group"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                        <Camera className="w-4 h-4" />
                      </div>
                      <div className="text-left">
                        <span className="block font-medium text-[#1E2837] dark:text-white">Upload Medicine Photo</span>
                        <span className="text-[10px] text-[#8B9DA8]">(Leave blank to use default icon)</span>
                      </div>
                    </div>
                    <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400">Select</span>
                  </button>
                )}
              </div>

              {/* Action Buttons (matching screenshot) */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#E3E8EE] dark:border-[#1e2d3d]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold border border-[#E3E8EE] dark:border-[#26374a] hover:bg-[#F3F6F9] dark:hover:bg-[#182635] text-[#64748B] dark:text-[#859ba8] transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-[#8b5cf6] hover:bg-[#7c3aed] text-white shadow-lg shadow-purple-500/25 transition-all flex items-center justify-center gap-2"
                >
                  <span>{submitting ? 'Adding...' : 'Add to Stock Inventory'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RESTOCK MODAL */}
      {showRestockModal && restockMedObj && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-md my-auto max-h-[90vh] bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-3xl p-6 shadow-2xl animate-fadeIn space-y-4 overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between pb-3 border-b border-[#E3E8EE] dark:border-[#1c3345]">
              <div className="flex items-center gap-2">
                <PackagePlus className="w-5 h-5 text-[#2E7D7E] dark:text-[#2dd4bf]" />
                <h3 className="font-bold text-sm text-[#1E2837] dark:text-white">
                  Restock {restockMedObj.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowRestockModal(false)}
                className="p-1 rounded-lg text-[#8B9DA8] hover:text-[#1E2837]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {restockMsg.text && (
              <div className={`p-2.5 rounded-xl text-xs ${restockMsg.isError ? 'bg-rose-50 text-rose-700' : 'bg-emerald-50 text-emerald-700'}`}>
                {restockMsg.text}
              </div>
            )}

            <form onSubmit={handleConfirmRestock} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#64748B] dark:text-[#859ba8] mb-1">
                  Quantity to Add ({restockMedObj.stock_unit || 'tablets'}):
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={addStockAmount}
                  onChange={(e) => setAddStockAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#F3F6F9] dark:bg-[#172838] border border-[#E3E8EE] dark:border-[#1c3345] rounded-xl text-xs text-[#1E2837] dark:text-white focus:outline-none focus:border-[#2E7D7E]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRestockModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#64748B] hover:bg-[#F3F6F9]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={restocking}
                  className="px-5 py-2 rounded-xl text-xs font-semibold bg-[#2E7D7E] hover:bg-[#26696a] text-white shadow-sm"
                >
                  {restocking ? 'Updating...' : 'Confirm Restock'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {pendingDeleteMed && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-[#13222f] border border-[#E3E8EE] dark:border-[#1c3345] rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-sm text-[#1E2837] dark:text-white">Delete Medication?</h3>
            <p className="text-xs text-[#8B9DA8]">
              Are you sure you want to remove <span className="font-bold text-[#1E2837] dark:text-white">{pendingDeleteMed.name}</span>?
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setPendingDeleteMed(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold text-[#64748B]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteMed}
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
